
let fs = require('fs');

/**
 * filename (String) 文件名称
 * data (String | Buffer) 将要写入的内容，可以是字符串或者 buffer 数据。
 * · encoding (String) 可选。默认 'utf-8'，当 data 是 buffer 时，该值应该为 ignored。
 * · mode (Number) 文件读写权限，默认 438。
 * · flag (String) 默认值 'w'。
 * callback { Function } 回调，传递一个异常参数 err。
 */
// fs.writeFile('index.js', 'Hello jsliang', (err) => {
//   if(err) {
//     console.log(err);
//     return false;
//   } else {
//     console.log('写入成功！');
//   }
// })

fs.appendFile('index.js', 'qwd s c 这段文本是要追加的内容', (err) => {
  if(err) {
    console.log(err);
    return false;
  } else {
    console.log("追加成功");
  }
})
fs.readFile('index.js', (err, data) => {
  if (err) {
    console.log(err);
    return false;
  } else {
    console.log("读取文件成功！");
    console.log(data);
  }
})

// fs.readdir('node_modules', (err, data) => {
//   if(err) {
//     console.log(err);
//     return false;
//   } else {
//     console.log("读取目录成功！");
//     console.log(data);
//     // Console：
//     // 读取目录成功！
//     // [ '03_tool-multiply.js', 'jsliang-module' ]
//   }
// })
