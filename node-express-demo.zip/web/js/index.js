let stackChart = null;
let stackChartHeight = 500;

	function init(){	
		let now = new Date();
		getSummaryInfo({
			type: $("#selectmenu").val(), //type为project或person
		  endTime: now.format('yyyy-MM-dd'), 
		})
	}

$('#clearBtn').on('click',function(){
	$(".lineContainer").hide();
	$("#stackContainer").show();
})

function changeType(value){
		getSummaryData();
}

function getSummaryData(){
	let type = $("#selectmenu").val();
	getSummaryInfo({
			type:type, //type为project或person
		})
}

function getSummaryInfo(option){		
	if(option && option.type){
		$.ajax({
	        type: "GET",
	        url: "http://192.168.16.38:8080/gerritinfo-api/query_info?type="+option.type,
	        timeout: 5000,
	        cache: false,
	        async: true,
	        success: function (result, textStatus) {
	          if(typeof result == "string"){
	        		let responseData = JSON.parse(result);
	        		let html = '';
	        		if( option.type == "project"){
	        			html = '总共<span style="color: blue">'+responseData.data.length+'</span>项目，其中<span id="oneWeekInactivity" style="color: orange">'+responseData.oneWeekInactivity+'</span>项目一周不活跃，<span id="twoWeekInactivity" style="color: red">'+responseData.twoWeekInactivity+'</span>项目两周不活跃';
	        		}else{
	        			html = '总共<span  style="color: blue">'+responseData.data.length+'</span>人，其中<span id="oneWeekInactivity" style="color: orange">'+responseData.oneWeekInactivity+'</span>人员一周不活跃，<span id="twoWeekInactivity" style="color: red">'+responseData.twoWeekInactivity+'</span>人员两周不活跃';
	        		}
	        		$('#comment').html(html);
	        		$('#time').html('统计时间：<span>'+responseData.startTime+" ~ "+responseData.endTime+'</span>');
	
	        		let data = ["增加数","进仓数"];
						  let yAxis = [],series = [],lineUnit = [],weekInactivity = [],tmp1 = [],tmp2 = [],tmp3 = [],tmp4 = [];
							
							stackChartHeight = 200+( responseData.data.length )*20
							$('#stackContainer').css('height',stackChartHeight+"px")
							
							responseData.data.map(function(item){				
								tmp4.push(item.addedCount+item.reviewCount);
							})
							
							let max = Math.max.apply(Math,tmp4); 
							let aa = max.toString().substr(0,1);
							let bb = Number(aa)+1;
							let cc = max.toString().split('.')[0].length;
							let maxData = bb * Math.pow(10,cc-1);
							
							responseData.data.map(function(item){
								lineUnit.push(item.lineUnit);
								weekInactivity.push(item.weekInactivity);
								yAxis.push(item.name);
								if(item.weekInactivity ==0){
									tmp1.push({value:item.addedCount});
									tmp3.push({value:item.reviewCount});
								}else{
									tmp1.push({value:item.reviewCount});
									tmp3.push({value:item.reviewCount,itemStyle:{color:"#ccc"}});
								}
								tmp2.push({name:item.name,value:maxData - item.addedCount -item.reviewCount ,itemStyle:{color:"transparent"}} );
							})
	
							series.push(tmp1.reverse());
							series.push(tmp3.reverse());		
							series.push(tmp2.reverse());
							
						  setOption(data, yAxis.reverse(), series,stackChartHeight,lineUnit.reverse(),weekInactivity.reverse(),maxData);
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	          //console.log(XMLHttpRequest)
	        }
    	});
	}
}
	
function getDetailInfo(option){		
	let startTime = option.startTime? option.startTime:"";
	$.ajax({
		type: "GET",
		url: "http://192.168.16.38:8080/gerritinfo-api/history_info?type="+option.type+"&startTime="+startTime+"&endTime="+option.endTime+"&searchName="+option.searchName,
		timeout: 5000,
		cache: false,
		async: true,
		success: function (result, textStatus) {
			if(typeof result == "string"){
				let responseData = JSON.parse(result);
				const xAxis = [];
				let startDate = responseData.startDate;
				let endDate = responseData.endDate;
				startDate.map((item,index)=>{
					var tmp = item+"-"+endDate[index];
					xAxis.push(tmp);
				})
				let series = [],yAxis = [],tmp1 = [],tmp2 = [],tmp3 = [];
						responseData.data.map(function(item){
							yAxis.push(item.name);
							tmp1.push(item.addedCount);
							tmp2.push(item.deletedCount);
							tmp3.push(item.reviewCount);
						})
						series.push(tmp1);
						series.push(tmp2);
						series.push(tmp3);
		
					setOption2(xAxis, series);
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
		  //console.log(XMLHttpRequest)
		}
	});
}

init();
setOption = (data, yAxis, series,stackChartHeight1,lineUnit,weekInactivity,maxData) => {
	let tmpSeries = [];
	if(series && series.length >0){
		series.map(function(item,index){
			tmpSeries.push(
				{
			        name: data[index],
			        type: "bar",
			        stack: "total",
			        data: item
			    }
			)
		})
	}

	var option = {
	    tooltip: {
		    trigger: "axis",
		    axisPointer: {
		        // 坐标轴指示器，坐标轴触发有效
		    	type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
		    },
		    formatter: function (params, ticket, callback) {
				if(params.length>1){
					let name = params[0].name;
					let index = params[0].dataIndex;
					
					let inactivity = weekInactivity[index];
					let str = "";
					if(inactivity == 0 ){
						let unit = lineUnit[index];
						str += name+ " (单位："+unit+")"+'<br /><br />'
						params.pop();
	//						console.log(tmp)
						params.map((item,index)=>{		   
				   			let value = item.value;
				   			let seriesName = item.seriesName;
				   			if(seriesName !=="series2"){
				   				str += seriesName+ " : " +value+'<br />'
				   			}				   			
						})
					}else if(inactivity == 1){
						str += name+'<br /><br />'
						str += '该项目或用户一周不活跃<br />'
					}
					else if(inactivity == 2){
						str += name+'<br /><br />'
						str += '该项目或用户两周不活跃<br />'
					}
					return str
				}
			}
	    },
	    legend: {
	      data: data
	    },
	    grid: {
	      left: "3%",
	      right: "4%",
	      bottom: "3%",
	      containLabel: true
	    },
	    xAxis: {
	      type: "value",
	      max:maxData,
	    },
	    yAxis: {
	      type: "category",
	      data: yAxis,
	      axisLabel:{
	      	color:function (value, index) {
	      		let tmp = weekInactivity[index];
				return tmp ==0 ? "#000":(tmp ==1 ? "orange":"red")
		    }
	      }
	    },
	    series: tmpSeries
  	};
  	
	let container = document.getElementById('stackContainer');
  	container.style.height = stackChartHeight1+'px';
  	
	if(stackChart){
		stackChart.dispose();
	}
  	stackChart = echarts.init(container);
  	stackChart.setOption(option);
  	stackChart.on('click',function(object){        
        // 初始化一个新的实例
        let searchName = object.name;
        let type = $("#selectmenu").val();
    	let startTime = undefined;
    	let endTime = undefined;
	   	$.ajax({
	        type: "GET",
	        url: "http://192.168.16.38:8080/gerritinfo-api/history_info?type="+type+"&startTime="+startTime+"&endTime="+endTime+"&searchName="+searchName,
	        timeout: 5000,
	        cache: false,
	        async: true,
	        success: function (result, textStatus) {
	       		if(typeof result == "string"){
	        		let responseData = JSON.parse(result);
	        		const xAxis = [];
	        		let startDate = responseData.startDate;
	        		let endDate = responseData.endDate;
	       			startDate.map((item,index)=>{
	       				var tmp = item+"-"+endDate[index];
	       				xAxis.push(tmp);
	       			})
	       			const series = [];
	       			const yAxis = [];
	       			var tmp1 = [];
							var tmp2 = [];
							var tmp3 = [];
							responseData.data.map(function(item){
								yAxis.push(item.name);
								tmp1.push(item.addedCount);
				
								tmp3.push(item.reviewCount);
							})
							series.push(tmp1);
				
							series.push(tmp3);
	
	  					setOption2(xAxis, series, searchName);
	        	}
	        },
	        error: function (XMLHttpRequest, textStatus, errorThrown) {
	          //console.log(XMLHttpRequest)
	        }
    	});
    });
};

setOption2 = (xAxis, series ,detailName) => {
	let tmpSeries = [];
	let legend = ["增加数","进仓数"]
	if(series && series.length >0){
		series.map(function(item,index){
			if(index == 0){
				tmpSeries.push(
					{
						smooth: true,
				        name: legend[index],
				        type: "line",
				        yAxisIndex:0,
				        data: item
		      		},
				)
			}else{
				tmpSeries.push(
					{
						smooth: true,
				        name: legend[index],
				        type: "line",
						yAxisIndex:1,
				        data: item
		      		},
				)
			}
		})
		$(".lineContainer").show();
		$("#stackContainer").hide();
	}else{
		$(".lineContainer").hide();
		$("#stackContainer").show();
	}
	let searchName = $("#searchName").val() || detailName;
  	let option2 = {
	    title: {
	      	left: "center",
	      	text:  searchName + " Commits"
	    },
	    tooltip: {
	      	trigger: "axis"
	    },
	    legend: {
		    orient: "horizontal", // 'vertical'
		    x: "center", // 'center' | 'left' | {number},
		    y: "bottom", // 'center' | 'bottom' | {number}
		    data: legend,
		    align: "left",
		    bottom: 50
	    },
	    grid: {
	      	left: "6%",
	      	right: "3%",
	      	bottom: 35,
	      	containLabel: true
	    },
		dataZoom:	 [
	    	{
		        type: 'slider',
		        show: true,
		        xAxisIndex: [0],
		        top:"bottom",
		   
		        left: '1%',
		        right:"1%",
		        start: 0, //数据窗口范围的起始百分比
		        end: 100
	        },
	      	{
		        type: 'inside',
		        xAxisIndex: [0],
		        start: 0,
		        end: 36
	      	}
	    ],
	    xAxis: {
	      	type: "category",
	      	boundaryGap: false,
	      	data: xAxis
	    },
	    yAxis: [
	        {
	            name: '增加数',
	            type: 'value',
	        },
	        {
	            name: '进仓数',
	            type: 'value',
	        }
	    ],
	    series: tmpSeries
  	};
  	let myChart2 = echarts.init(document.getElementById("lineContainer"));
  	myChart2.setOption(option2);
};
