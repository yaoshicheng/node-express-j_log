var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '!Ysc901213',
  database : 'test'
});

connection.connect();

connection.query('SELECT * from runoob_tbl', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is: ', results);
});

