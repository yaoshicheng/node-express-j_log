var express = require('express');
var router = express.Router();

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '!Ysc901213',
  database : 'JLog'
});

connection.connect();

/* GET users listing. */
router.get('/', function(req, res, next) {
  connection.query('SELECT os_version, msg,error_url,line,col,error,url,browser,product_name,error_time,os,extend,ua from j_log', function (error, results, fields) {
    if (error) throw error;
    res.json({
      data:results,
      success:true,
      code:null,
    });
  });
});

router.post('/', function(req, res, next) {
  if(req.body ) {
    var  addSql = 'INSERT INTO j_log (os_version, msg,error_url,line,col,error,url,browser,product_name,error_time,os,extend,ua) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);';
    var  addSqlParams = [
      req.body.osVersion,
      req.body.msg,
      req.body.errUrl,
      req.body.line,
      req.body.col,
      req.body.error,
      req.body.url,
      req.body.browser,
      req.body.productname,
      req.body.errortime,
      req.body.os,
      req.body.extend,
      req.body.ua,
    ];
    connection.query(addSql,addSqlParams, function (error, results, fields ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
    });
  }
});

router.delete('/', function(req, res, next) {
  if(req.body && req.body.title ) {
    var  deleteSql = 'DELETE FROM j_log WHERE runoob_title = ?';
    var deleteParam = [req.body.title]
    connection.query(deleteSql, deleteParam,function (error, results ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
    });
  }
});

router.put('/', function(req, res, next) {
  if(req.body ) {
    var userModSql = 'UPDATE j_log SET runoob_title = ?,runoob_author = ? WHERE runoob_id = ?';
    var userModSql_Params = [req.body.title,req.body.author,req.body.id];
    connection.query(userModSql, userModSql_Params,function (error, results ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
      console.log('The solution is: ', results);
    });
  }
});
module.exports = router;
