var express = require('express');
var router = express.Router();

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '!Ysc901213',
  database : 'JLog'
});

connection.connect();

/* GET users listing. */
router.get('/', function(req, res, next) {
  connection.query('SELECT * from j_log', function (error, results, fields) {
    if (error) throw error;

    res.json({
      data:results,
      success:true,
      code:null,
    });
    console.log('The solution is: ', results);
  });
});

router.post('/', function(req, res, next) {
  console.log(typeof req.body )
  if(req.body && req.body.title && req.body.author ) {
    var  addSql = 'INSERT INTO j_log (runoob_title, runoob_author, submission_date) VALUES (?,?,?);';
    var  addSqlParams = [req.body.title, req.body.author,new Date()];
    connection.query(addSql,addSqlParams, function (error, results, fields ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
      // console.log('The solution is: ', results);
    });
  }
});

router.delete('/', function(req, res, next) {
  if(req.body && req.body.title ) {
    var  deleteSql = 'DELETE FROM runoob_tbl WHERE runoob_title = ?';
    var deleteParam = [req.body.title]
    connection.query(deleteSql, deleteParam,function (error, results ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
    });
  }
});

router.put('/', function(req, res, next) {
  if(req.body ) {
    var userModSql = 'UPDATE j_log SET runoob_title = ?,runoob_author = ? WHERE runoob_id = ?';
    var userModSql_Params = [req.body.title,req.body.author,req.body.id];
    connection.query(userModSql, userModSql_Params,function (error, results ) {
      if (error) throw error;
      res.send({
        data: results,
        success: true,
        code: null,
      });
      console.log('The solution is: ', results);
    });
  }
});
module.exports = router;
